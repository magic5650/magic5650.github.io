local limit_req = require "resty.limit.req"
local error_code = 503
local rate = 10 --固定平均速率10r/s
local burst = 10 --桶容量
local nodelay = false --是否需要不延迟处理


-- function split(str, pat) --字符串分割函数
--    local t = {}  -- NOTE: use {n = 0} in Lua-5.0
--    local fpat = "(.-)" .. pat
--    local last_end = 1
--    local s, e, cap = str:find(fpat, 1)
--    while s do
--       if s ~= 1 or cap ~= "" then
--          table.insert(t,cap)
--       end
--       last_end = e+1
--       s, e, cap = str:find(fpat, last_end)
--    end
--    if last_end <= #str then
--       cap = str:sub(last_end)
--       table.insert(t, cap)
--    end
--    return t
-- end


local xforwardedfor = ngx.req.get_headers()["X-Forwarded-For"] --获取X-Forwarded-For
if xforwardedfor then
    iptable = ngx.re.split(xforwardedfor,',') --分割X-Forwarded-For
    client_ip_index = #iptable - 1
    client_ip = iptable[client_ip_index] --获取真实用户IP

    if client_ip then
        local lim, err = limit_req.new("limit_req_store", rate, burst)
        if not lim then --没定义共享字典
            ngx.exit(error_code)
        end
        --local key = ngx.var.binary_remote_addr --IP维度限流
        local key = client_ip --真实用户IP维度限流
        --请求流入，如果你的请求需要被延迟则返回delay>0
        local delay, err = lim:incoming(key, true)
        if not delay and err == "rejected" then
            ngx.log(ngx.ERR, "failed to limit req: ", err)
            ngx.exit(error_code)
        end
        if delay > 0 then --根据需要决定延迟或者不延迟处理
            if nodelay then
                --直接突发处理
            else
                ngx.sleep(delay) --延迟处理
            end
        end
    end
else
--待定
end

