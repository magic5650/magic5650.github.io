local init = require "waf.init"

-- function waf_main()
--     if init.white_ip_check() then
--     elseif init.white_url_check() then
--     elseif init.black_ip_check() then
--     elseif init.user_agent_attack_check() then
--     elseif init.cc_attack_check() then
--     elseif init.cookie_attack_check() then
--     elseif init.url_attack_check() then
--     else init.url_args_attack_check() then
--         return
--     end
-- end

-- waf_main()

function waf_main()
    if init.user_agent_attack_check() then
    elseif init.url_args_attack_check() then
    elseif init.cookie_attack_check() then
    elseif init.cc_attack_check(100,100) then
    elseif init.post_attack_check() then
    -- elseif init.limit_attack_check(50,50) then
        return
    end
end

waf_main()


