local _M = {_VERSION = "0.1"}

--WAF Action

local cjson = require "cjson"
local limit_req = require "resty.limit.req"
local ngx_re = require "ngx.re"
local parser = require "resty.multipart.parser"

--args
local match = string.match
local rulematch = ngx.re.find
local re_match = ngx.re.match
local unescape = ngx.unescape_uri

output_html=[[
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="zh-cn" />
<title>Nimo web firewall</title>
</head>
<body>
<h1 align="center"> 
Welcome white hat for authorization security test, please contact email for security flaw: magic5650@126.com.
</body>
</html>
]]


--WAF return
local function waf_output()
    ngx.header.content_type = "text/html"
    ngx.say(output_html)
    -- ngx.exit(ngx.HTTP_FORBIDDEN)
end

local function get_client_ip()
    arch_type = 3
    xforwardedfor = ngx.req.get_headers()["X-Forwarded-For"]
    iplist = ngx_re.split(xforwardedfor,',') --分割X-Forwarded-For
    if arch_type == 1 then -- cloudfront + elb
        client_ip_index = #iplist-1
        client_ip = iplist[client_ip_index] --获取真实用户IP
    elseif arch_type == 2 then -- only elb or cloudfront
        client_ip_index = #iplist
        client_ip = iplist[client_ip_index] --获取真实用户IP
    elseif arch_type == 3 then -- without cloudfront and elb
        client_ip = ngx.var.remote_addr
    end
    if client_ip ~= "" then
        return client_ip
    else
        -- return "unknow"
        return "unknow"..string.sub(ngx.time(),1,-1)
    end
end

--Get WAF rule
local function get_rule(filename)
    local io = require 'io'
    local RULE_PATH = "/usr/local/nginx/lualib/waf/rule-config"
    local RULE_FILE = io.open(RULE_PATH..'/'..filename,"r")
    if RULE_FILE == nil then
        ngx.log(ngx.ERR, "RULE_FILE: is no exist. ", RULE_PATH..'/'..filename)
        return false
    end
    RULE_TABLE = {}
    for line in RULE_FILE:lines() do
        table.insert(RULE_TABLE,line)
    end
    RULE_FILE:close()
    return(RULE_TABLE)
end

--WAF log record for json,(use logstash codec => json)
local function log_record(method,url,data,rule)
    local cjson = require "cjson"
    local io = require "io"
    local LOG_PATH = "/data/weblog/nginx"
    local CLIENT_IP = get_client_ip()
    local USER_AGENT = ngx.var.http_user_agent
    local SERVER_NAME = ngx.var.server_name
    local LOCAL_TIME = ngx.localtime()
    local json_obj = {
            client_ip = CLIENT_IP,
            local_time = LOCAL_TIME,
            server_name = SERVER_NAME,
            user_agent = USER_AGENT,
            attack_method = method,
            req_url = url,
            match_data = data,
            match_rule = rule,
        }
    local LOG_LINE = cjson.encode(json_obj)
    -- LOG_LINE=string.gsub(LOG_LINE,"\\","")
    -- local LOG_NAME = LOG_PATH..'/'..ngx.today().."_waf.log"
    local LOG_NAME = LOG_PATH.."/waf.log"
    local file = io.open(LOG_NAME,"a")
    if file == nil then
        return
    end
    file:write(LOG_LINE.."\n")
    file:flush()
    file:close()
end


--allow white ip
function _M.white_ip_check()
    local IP_WHITE_RULE = get_rule("whiteip.rule")
    local WHITE_IP = get_client_ip()
    if IP_WHITE_RULE ~= nil then
        for _,rule in pairs(IP_WHITE_RULE) do
            if rule ~= "" and rulematch(WHITE_IP,rule,"jo") then
                return true
            end
        end
    end
    return false
end

--allow white url
function _M.white_url_check()
    local URL_WHITE_RULES = get_rule("whiteurl.rule")
    local REQ_URI = ngx.var.request_uri
    if URL_WHITE_RULES ~= nil then
        for _,rule in pairs(URL_WHITE_RULES) do
            if rule ~= "" and rulematch(REQ_URI,rule,"jo") then
                return true
            end
        end
    end
    return false
end

--deny black ip
function _M.black_ip_check()
    local IP_BLACK_RULE = get_rule("blackip.rule")
    local BLACK_IP = get_client_ip()
    if IP_BLACK_RULE ~= nil then
        for _,rule in pairs(IP_BLACK_RULE) do
            if rule ~= "" and rulematch(BLACK_IP,rule,"jo") then
                log_record("black_ip",ngx.var_request_uri,BLACK_IP,rule)
                waf_output()
            end
        end
    end
    return false
end

--deny url
function _M.url_attack_check()
    local URL_RULES = get_rule("url.rule")
    local REQ_URI = ngx.var.request_uri
    for _,rule in pairs(URL_RULES) do
        if rule ~="" and rulematch(REQ_URI,rule,"jo") then
            log_record("url_attack",REQ_URI,REQ_URI,rule)
            waf_output()
        end
    end
    return false
end

--deny user agent
function _M.user_agent_attack_check()
    local USER_AGENT_RULES = get_rule("useragent.rule")
    local USER_AGENT = ngx.var.http_user_agent
    if USER_AGENT ~= nil then
        for _,rule in pairs(USER_AGENT_RULES) do
            if rule ~="" and rulematch(USER_AGENT,rule,"jo") then
                log_record("user_agent_attack",ngx.var.request_uri,USER_AGENT,rule)
                waf_output()
            end
        end
    end
    return false
end

--deny url args
function _M.url_args_attack_check()
    local ARGS_RULES = get_rule("args.rule")
    local REQ_ARGS = ngx.req.get_uri_args()
    for _,rule in pairs(ARGS_RULES) do
        for key, val in pairs(REQ_ARGS) do
            if type(val) == "table" then
                ARGS_DATA = table.concat(val, " ")
            else
                ARGS_DATA = val
            end
            if ARGS_DATA and type(ARGS_DATA) ~= "boolean" and rule ~="" and rulematch(unescape(ARGS_DATA),rule,"jo") then
                log_record("url_args_attack",ngx.var.request_uri,ARGS_DATA,rule)
                waf_output()
            end
        end
    end
    return false
end

--deny cookie
function _M.cookie_attack_check()
    local COOKIE_RULES = get_rule("cookie.rule")
    local USER_COOKIE = ngx.var.http_cookie
    if USER_COOKIE ~= nil then
        for _,rule in pairs(COOKIE_RULES) do
            if rule ~="" and rulematch(USER_COOKIE,rule,"jo") then
                log_record("cookie_attack",ngx.var.request_uri,USER_COOKIE,rule)
                waf_output()
            end
         end
     end
    return false
end

--deny cc attack
function _M.cc_attack_check(rate,burst)
    local rate = rate or 0
    local burst = burst or 0
    local uri=ngx.var.uri
    -- local key = get_client_ip()..uri
    local key = get_client_ip()
    local lim, err = limit_req.new("cc_req_store", rate, burst)
    if not lim then --没定义共享字典
        ngx.log(ngx.ERR,"lua_shared_dict cc_req_store not defind.")
        ngx.exit(403)
    end

    local delay, err = lim:incoming(key, true)
    if not delay and err == "rejected" then
        log_record("cc_attack",ngx.var.request_uri,key,err)
        ngx.exit(403)
        -- waf_output()
    end

    if delay > 0 then
        --直接突发处理
    end
    return false
end

--limit traffic by key combine by client_ip and uri
function _M.limit_attack_check(rate,burst)
    local rate = rate or 0
    local burst = burst or 0
    local uri=ngx.var.uri
    local key = get_client_ip()..uri
    local lim, err = limit_req.new("limit_req_store", rate, burst)
    if not lim then --没定义共享字典
        ngx.log(ngx.ERR,"lua_shared_dict limit_req_store not defind.")
        ngx.exit(403)
    end

    local delay, err = lim:incoming(key, true)
    if not delay and err == "rejected" then
        log_record("limit_attack",ngx.var.request_uri,key,err)
        ngx.exit(403)
        -- waf_output()
    end

    if delay > 0 then
        --直接突发处理
    end
    return false
end

--ngx.req.get_body_data() 读请求体，会偶尔出现读取不到直接返回 nil 的情况。
--如果请求体已经被存入临时文件，请使用 ngx.req.get_body_file 函数代替。
--- 获取所有POST参数（包含表单）
local function get_post_all()
    --ngx.req.read_body()
    local data = ngx.req.get_body_data() --ngx.req.get_post_args()
    if not data then
        local datafile =ngx.req.get_body_file()
        if datafile then
            local fh, err = io.open(datafile,"r")
            if fh then
                fh:seek("set")
                data = fh:read("*a")
                fh:close()
            end
        end
    end
    return ngx.unescape_uri(data)
end

--https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Methods/POST
--if post is multipart/form-data
local function get_boundary()
    local header = ngx.var.http_content_type
    if not header then
        return nil
    end
   local match_table = {}
   match_table[1] = nil
   match_table[2] = nil
   local m, err = re_match(header,
                  [[;\s*boundary\s*=\s*(?:"([^"]+)"|([-|+*$&!.%'`~^\#\w]+))]],
                           "joi", nil, match_table)
    if m then
       return m[1] or m[2]
    end
    if err then
       return nil
    end
    return nil
end

-- if post is json
local function get_json()
    local header = ngx.var.http_content_type
    if not header then
        return nil
    end
    local m, err = re_match(header,"application/json")
    if m then
       return m[0]
    end
    if err then
       return nil
    end
    return nil
end

-- multipart/form-data方式的数据，只要其中带有文件，则不检查
-- application/x-www-form-urlencoded二进制模式发送的文件会被检查
--deny post attack
function _M.post_attack_check()
    local method = ngx.req.get_method()
    -- 如果请求体尚未被读取，请先调用 ngx.req.read_body (或打开 lua_need_request_body 选项强制本模块读取请求体，此方法不推荐）。
    ngx.req.read_body()
    if method == "POST" then
        local boundary = get_boundary()
        local json =get_json()
        -- ngx.log(ngx.ERR,"json: ",json)
        -- ngx.log(ngx.ERR,"boundary: ",boundary)
        if json then
            --not done
            -- ngx.log(ngx.ERR,"json: ",json)
            return false
        end
        -- not multipart/form-data
        if not boundary then
            local postargs = ngx.req.get_post_args()
            local POST_RULES = get_rule("post.rule")
            if postargs then
                for _,rule in pairs(POST_RULES) do
                    for key, val in pairs(postargs) do
                        if type(val) == "table" then
                            if type(val[1]) == "boolean" then
                                return false
                            end
                            ARGS_DATA=table.concat(val, ", ")
                        else
                            ARGS_DATA=val
                        end
                        if ARGS_DATA and type(ARGS_DATA) ~= "boolean" and rule ~="" and rulematch(unescape(ARGS_DATA),rule,"jo") then
                            log_record("post_attack",ngx.var.request_uri,ARGS_DATA,rule)
                            waf_output()
                        end
                    end
                end
            else
                --not done
                return false    
            end
        else
            body = get_post_all()
            -- body = ngx.req.get_body_data()
            local p, err = parser.new(body, ngx.var.http_content_type)
            if not p then
                ngx.log(ngx.ERR, "parser nil")
                return false
            end

            while true do
                local part_body, name, mime, filename = p:parse_part()
                -- ngx.log(ngx.ERR,"name: [", name, "]")
                -- ngx.log(ngx.ERR,"file: [", filename, "]")
                -- ngx.log(ngx.ERR,"mime: [", mime, "]")
                -- ngx.log(ngx.ERR,"body: [", part_body, "]")
                if not part_body then
                    break
                end
                -- if mine is nil or text or image
                if not mime and name ~="" then
                    local POST_RULES = get_rule("post.rule")
                    for _,rule in pairs(POST_RULES) do
                        if rule ~="" and rulematch(part_body,rule,"jo") then
                            log_record("post_attack",ngx.var.request_uri,part_body,rule)
                            waf_output()
                        end
                    end
                else
                    --not done
                    return false
                end
            end
        end
    end
    return false
end


return _M
